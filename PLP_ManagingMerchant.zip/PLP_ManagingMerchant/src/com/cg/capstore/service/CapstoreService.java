package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Merchant;



public interface CapstoreService {

	public void save(Merchant merchant);
	public void delete(String merchantUId);
	public List<Merchant> loadAll();
}
