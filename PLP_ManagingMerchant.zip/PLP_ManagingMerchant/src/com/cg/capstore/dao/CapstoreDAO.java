package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.dto.Merchant;




public interface CapstoreDAO {

	public void save(Merchant merchant);
	public void delete(String merchantUId);
	public List<Merchant> loadAll();
}
