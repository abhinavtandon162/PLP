

package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="Merchant_Details")
public class Merchant {

	@Id
	@Column(name="merchant_id",length=10)
	@NotNull(message="Enter merchant User ID")
	private String merchantUId;
	
	@Column(name="merchant_name")
	@NotNull(message="Enter merchant name")
	private String merchantName;
	
	@Column(name="merchant_company_name")
	@NotNull(message="Enter company name of mercant")
	private String merchantCompanyName;
	
	@Column(name="merchant_company_address")
	private String merchantCompanyAddress;
	
	@Column(name="merchant_mobileNo")
	@NotNull(message="Enter mobile no. of merchant")
	private String merchantMobNo;
	
	@Column(name="merchant_rating")
	private double rating;
	
	@Column(name="merchant_type")
	private String merchantType;

	public String getMerchantUId() {
		return merchantUId;
	}

	public void setMerchantUId(String merchantUId) {
		this.merchantUId = merchantUId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantCompanyName() {
		return merchantCompanyName;
	}

	public void setMerchantCompanyName(String merchantCompanyName) {
		this.merchantCompanyName = merchantCompanyName;
	}

	public String getMerchantCompanyAddress() {
		return merchantCompanyAddress;
	}

	public void setMerchantCompanyAddress(String merchantCompanyAddress) {
		this.merchantCompanyAddress = merchantCompanyAddress;
	}

	public String getMerchantMobNo() {
		return merchantMobNo;
	}

	public void setMerchantMobNo(String merchantMobNo) {
		this.merchantMobNo = merchantMobNo;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	@Override
	public String toString() {
		return "Merchant [merchantUId=" + merchantUId + ", merchantName="
				+ merchantName + ", merchantCompanyName=" + merchantCompanyName
				+ ", merchantCompanyAddress=" + merchantCompanyAddress
				+ ", merchantMobNo=" + merchantMobNo + ", rating=" + rating
				+ ", merchantType=" + merchantType + "]";
	}

	public Merchant(String merchantUId, String merchantName,
			String merchantCompanyName, String merchantCompanyAddress,
			String merchantMobNo, double rating, String merchantType) {
		super();
		this.merchantUId = merchantUId;
		this.merchantName = merchantName;
		this.merchantCompanyName = merchantCompanyName;
		this.merchantCompanyAddress = merchantCompanyAddress;
		this.merchantMobNo = merchantMobNo;
		this.rating = rating;
		this.merchantType = merchantType;
	}

	public Merchant() {
		super();
	}

	
	
	
	
	
	
}
