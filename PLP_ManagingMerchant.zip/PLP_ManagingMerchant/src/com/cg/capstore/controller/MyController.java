package com.cg.capstore.controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.service.CapstoreService;




@Controller
public class MyController {

	@Autowired
	CapstoreService capstoreservice;

	public CapstoreService getCapstoreservice() {
		return capstoreservice;
	}

	public void setCapstoreservice(CapstoreService capstoreservice) {
		this.capstoreservice = capstoreservice;
	}

	@RequestMapping("home")
	public String showStockList(Model model)
	{
		return "Home";
	}

	@RequestMapping(value="addMerchant")
	public String addEmployee(@ModelAttribute("merch") Merchant merchant ){
		return "Add_Merchant";
	}

	@RequestMapping(value="save",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@ModelAttribute("merch") Merchant merchant,BindingResult result){
		
		if(result.hasErrors()){

			return new ModelAndView("Add_Merchant");
		}
		else
		{
			capstoreservice.save(merchant);
		
			return new ModelAndView("Home");
		}
		
	}
	@RequestMapping(value="deleteMerchant")
	public String deleteMerchant(){
		
		return "Delete_Merchant";
	}
	
	@RequestMapping(value="delete")
	public String merchantDelete(@RequestParam("merchantUId") String merchUId){
		capstoreservice.delete(merchUId);
		return "Home";
		
	}
	@RequestMapping(value="showAllMerchant")
	public ModelAndView showAllTrainee(){
		List<Merchant> allmerchant=capstoreservice.loadAll();
		return new ModelAndView("showAll","merchantList", allmerchant);
	}
}
